
import React, { useState, useEffect } from 'react';
import { Home, BookOpen, Settings as SettingsIcon, Moon, Sun, ChevronLeft, ChevronRight, Download, Image as ImageIcon, FileText, Loader2, List, Bookmark as BookmarkIcon, Maximize, Minimize } from 'lucide-react';
import * as htmlToImage from 'html-to-image';
import SurahList from './components/SurahList';
import MushafView from './components/MushafView';
import SettingsMenu from './components/SettingsMenu';
import JumpToSurahModal from './components/JumpToSurahModal';
import AuthGuard from './components/AuthGuard';
import { Theme, AppSettings, Surah, BorderStyle } from './types';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<number | null>(null); // null means home
  const [showSettings, setShowSettings] = useState(false);
  const [showJumpModal, setShowJumpModal] = useState(false);
  const [showDownloadMenu, setShowDownloadMenu] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [bookmark, setBookmark] = useState<number | null>(null);
  const [settings, setSettings] = useState<AppSettings>({
    theme: Theme.Light,
    fontSize: 32,
    opacity: 100,
    fontFamily: 'Uthmanic',
    borderStyle: BorderStyle.Ornate
  });

  // Load bookmark on mount
  useEffect(() => {
    const savedBookmark = localStorage.getItem('mushaf_bookmark');
    if (savedBookmark) {
      setBookmark(parseInt(savedBookmark));
    }

    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleTheme = () => {
    setSettings(prev => ({
      ...prev,
      theme: prev.theme === Theme.Light ? Theme.Dark : Theme.Light
    }));
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Error attempting to enable fullscreen mode: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  };

  useEffect(() => {
    if (settings.theme === Theme.Dark) {
      document.body.classList.add('bg-neutral-900', 'text-white');
      document.body.classList.remove('bg-slate-50', 'text-slate-900');
    } else {
      document.body.classList.add('bg-slate-50', 'text-slate-900');
      document.body.classList.remove('bg-neutral-900', 'text-white');
    }
  }, [settings.theme]);

  const navigateToPage = (pageNum: number) => {
    setCurrentPage(pageNum);
    setShowDownloadMenu(false);
    setShowJumpModal(false);
  };

  const handleSelectSurah = (surah: Surah) => {
    navigateToPage(surah.startPage);
  };

  const handleToggleBookmark = (page: number) => {
    if (bookmark === page) {
      setBookmark(null);
      localStorage.removeItem('mushaf_bookmark');
    } else {
      setBookmark(page);
      localStorage.setItem('mushaf_bookmark', page.toString());
    }
  };

  const downloadAsImage = async () => {
    const node = document.getElementById('mushaf-page');
    if (!node || isDownloading) return;

    setIsDownloading(true);
    setShowDownloadMenu(false);
    
    try {
      // Pastikan font sudah dimuat sepenuhnya
      await document.fonts.ready;
      
      // Berikan jeda sedikit agar layout stabil
      await new Promise(resolve => setTimeout(resolve, 200));

      const dataUrl = await htmlToImage.toPng(node, {
        quality: 1,
        pixelRatio: 3, // Meningkatkan kepadatan pixel untuk hasil tajam
        backgroundColor: settings.theme === Theme.Dark ? '#171717' : '#fffcf0',
        style: {
           borderRadius: '0',
           boxShadow: 'none',
           margin: '0',
           padding: '40px', // Memberikan padding seragam saat download
           transform: 'none',
           // Memastikan lebar pas saat di-capture di layar kecil
           width: '850px',
           height: 'auto',
           maxWidth: 'none'
        },
        // Filter elemen UI yang tidak perlu ikut terunduh
        filter: (el) => {
          return !el.classList?.contains('no-print');
        }
      });
      
      const link = document.createElement('a');
      link.download = `Mushaf-Halaman-${currentPage}.png`;
      link.href = dataUrl;
      link.click();
    } catch (error) {
      console.error('Failed to download image:', error);
      alert('Maaf, gagal mengambil gambar. Silakan coba lagi.');
    } finally {
      setIsDownloading(false);
    }
  };

  const downloadAsPdf = () => {
    setShowDownloadMenu(false);
    window.print();
  };

  return (
    <AuthGuard>
      <div className={`min-h-screen flex flex-col transition-colors duration-300 ${settings.theme === Theme.Dark ? 'bg-neutral-900' : 'bg-slate-50'}`}>
        {/* Header */}
        {!isFullscreen && (
          <header className={`sticky top-0 z-40 px-6 py-4 border-b backdrop-blur-md flex justify-between items-center ${
            settings.theme === Theme.Dark ? 'bg-neutral-900/80 border-neutral-800' : 'bg-white/80 border-slate-200'
          }`}>
            <div className="flex items-center gap-3">
              <div className="bg-emerald-600 p-2 rounded-lg text-white shadow-lg shadow-emerald-600/20">
                <BookOpen size={24} />
              </div>
              <div>
                <h1 className="font-bold text-lg">Al-Qur'anul Karim</h1>
                <p className="text-xs opacity-60 uppercase tracking-widest font-medium">Digital Mushaf Edition</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button 
                onClick={toggleTheme}
                title="Ganti Tema"
                className={`p-2 rounded-full transition-colors ${
                  settings.theme === Theme.Dark ? 'hover:bg-neutral-800 text-yellow-400' : 'hover:bg-slate-100 text-slate-500'
                }`}
              >
                {settings.theme === Theme.Dark ? <Sun size={20} /> : <Moon size={20} />}
              </button>
              {currentPage !== null && (
                <button 
                  onClick={() => setShowSettings(true)}
                  title="Pengaturan"
                  className={`p-2 rounded-full transition-colors ${
                    settings.theme === Theme.Dark ? 'hover:bg-neutral-800 text-neutral-400' : 'hover:bg-slate-100 text-slate-500'
                  }`}
                >
                  <SettingsIcon size={20} />
                </button>
              )}
            </div>
          </header>
        )}

        {/* Main Content */}
        <main className={`flex-1 overflow-hidden relative ${isFullscreen ? 'pt-0' : ''}`}>
          {currentPage === null ? (
            <div className="h-full flex flex-col">
              {bookmark && (
                <div className="px-6 pt-6 max-w-7xl mx-auto w-full">
                  <button 
                    onClick={() => navigateToPage(bookmark)}
                    className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 border-emerald-500/30 bg-emerald-500/5 hover:bg-emerald-500/10 transition-all group ${
                      settings.theme === Theme.Dark ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="bg-emerald-500 p-3 rounded-xl text-white shadow-md">
                        <BookmarkIcon size={20} fill="currentColor" />
                      </div>
                      <div className="text-left">
                        <p className="text-sm font-bold opacity-70 uppercase tracking-tight">Lanjutkan Membaca</p>
                        <p className="font-bold text-lg">Halaman {bookmark}</p>
                      </div>
                    </div>
                    <ChevronRight size={24} className="text-emerald-500 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              )}
              <SurahList onSelectSurah={handleSelectSurah} theme={settings.theme} />
            </div>
          ) : (
            <MushafView 
              page={currentPage} 
              settings={settings}
              onPageChange={setCurrentPage}
              onGoHome={() => setCurrentPage(null)}
              bookmark={bookmark}
              onToggleBookmark={() => handleToggleBookmark(currentPage)}
            />
          )}
        </main>

        {/* Navigation Footer (Floating for Mushaf) */}
        {currentPage !== null && (
          <footer className={`fixed bottom-6 left-1/2 -translate-x-1/2 px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-6 z-50 transition-all border ${
            settings.theme === Theme.Dark ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-white border-slate-200 text-slate-900'
          } ${isFullscreen ? 'opacity-40 hover:opacity-100' : ''}`}>
            <button 
              onClick={() => navigateToPage(Math.max(1, currentPage - 1))}
              className="hover:text-emerald-500 transition-colors disabled:opacity-30"
              disabled={currentPage <= 1}
            >
              <ChevronLeft size={24} />
            </button>
            
            <div className="flex flex-col items-center min-w-[80px]">
              <span className="text-xs opacity-50 font-semibold uppercase">Halaman</span>
              <span className="font-bold text-lg">{currentPage}</span>
            </div>

            <button 
               onClick={() => navigateToPage(Math.min(604, currentPage + 1))}
               className="hover:text-emerald-500 transition-colors disabled:opacity-30"
               disabled={currentPage >= 604}
            >
              <ChevronRight size={24} />
            </button>

            <div className="w-[1px] h-6 bg-slate-300/30"></div>

            <div className="flex items-center gap-4">
              <button 
                onClick={toggleFullscreen}
                title={isFullscreen ? "Keluar Layar Penuh" : "Layar Penuh Imersif"}
                className={`transition-colors p-1 rounded-lg ${
                  isFullscreen 
                  ? 'text-amber-500 bg-amber-500/10 hover:bg-amber-500/20' 
                  : 'hover:text-emerald-500 hover:bg-emerald-500/10'
                }`}
              >
                {isFullscreen ? <Minimize size={22} /> : <Maximize size={22} />}
              </button>

              <div className="relative">
                <button 
                  onClick={() => setShowDownloadMenu(!showDownloadMenu)}
                  title="Unduh Halaman"
                  className={`hover:text-emerald-500 transition-colors relative ${isDownloading ? 'animate-pulse' : ''}`}
                  disabled={isDownloading}
                >
                  {isDownloading ? <Loader2 size={22} className="animate-spin" /> : <Download size={22} />}
                </button>
                
                {showDownloadMenu && (
                  <div className={`absolute bottom-full mb-4 left-1/2 -translate-x-1/2 min-w-[200px] rounded-2xl shadow-2xl border overflow-hidden p-2 flex flex-col gap-1 transition-all animate-in slide-in-from-bottom-2 duration-200 ${
                    settings.theme === Theme.Dark ? 'bg-neutral-900 border-neutral-700' : 'bg-white border-slate-100'
                  }`}>
                    <button 
                      onClick={downloadAsImage}
                      className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl text-left text-sm font-semibold transition-colors ${
                        settings.theme === Theme.Dark ? 'hover:bg-neutral-800 text-white' : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <ImageIcon size={18} className="text-emerald-500" /> Simpan Gambar (PNG)
                    </button>
                    <button 
                      onClick={downloadAsPdf}
                      className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl text-left text-sm font-semibold transition-colors ${
                        settings.theme === Theme.Dark ? 'hover:bg-neutral-800 text-white' : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <FileText size={18} className="text-emerald-500" /> Cetak / Simpan PDF
                    </button>
                  </div>
                )}
              </div>

              <button 
                onClick={() => setShowJumpModal(true)}
                title="Lompat ke Surah"
                className="hover:text-emerald-500 transition-colors"
              >
                <List size={22} />
              </button>

              <button 
                onClick={() => setCurrentPage(null)}
                title="Ke Beranda"
                className="hover:text-emerald-500 transition-colors"
              >
                <Home size={22} />
              </button>
            </div>
          </footer>
        )}

        {/* Overlays */}
        {showSettings && (
          <SettingsMenu 
            settings={settings} 
            setSettings={setSettings} 
            onClose={() => setShowSettings(false)} 
          />
        )}

        {showJumpModal && (
          <JumpToSurahModal 
            theme={settings.theme}
            onSelect={handleSelectSurah}
            onClose={() => setShowJumpModal(false)}
          />
        )}
      </div>
    </AuthGuard>
  );
};

export default App;
